const net = require("net");

const connectedSockets = new Set();

connectedSockets.broadcast = function (data, sender) {
  for (const socket of this) {
    if (socket !== sender) {
      socket.write(`> ${data}`);
    }
  }
};

const server = net
  .createServer(socket => {
    // 'connection' listener.
    console.log("client connected");
    connectedSockets.add(socket);

    socket.on("data", data => {
      connectedSockets.broadcast(data, socket);
    });

    socket.on("end", () => {
      console.log("client disconnected");
      connectedSockets.delete(socket);
    });
  })
  .on("error", err => {
    // Handle errors here.
    throw err;
  });

// Grab an arbitrary unused port
// Connect with "nc 127.0.0.1 8000" (MacOS)
server.listen(8000, "127.0.0.1");
