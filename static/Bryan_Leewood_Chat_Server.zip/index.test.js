test("Calc sum", () => {
  const sum = 5;
  expect(sum).toBe(5);
});
